// 製作一個問答程式 \n可以在小視窗裡面換行
// 先把問題都存放在陣列裡面
let questions = [
    {
        prompt:"凱文的身高?\n(a)172cm\n(b)177cm\n(c)175cm",
        answer:"c"
    },
    {
        prompt:"凱文的生日?\n(a)5/5\n(b)5/2\n(c)5/3",
        answer:"b"
    },
    {
        prompt:"凱文怕什麼?\n(a)蝴蝶\n(b)鬼\n(c)以上皆是",
        answer:"c"
    },
    {
        prompt:"凱文最想帶媽媽去哪裡?\n(a)法國\n(b)冰島\n(c)威尼斯",
        answer:"a"
    },
    {
        prompt:"凱文的MBTI?\n(a)INFJ\n(b)INTJ\n(c)INFP",
        answer:"a"
    },
    {
        prompt:"凱文的父母?\n(a)同居\n(b)離婚\n(c)分居",
        answer:"c"
    },
    {
        prompt:"凱文跟芝廷的紀念日?\n(a)11/22\n(b)11/20\n(c)11/21",
        answer:"c"
    },
    {
        prompt:"凱文最想跟芝廷去哪裡?\n(a)冰島\n(b)威尼斯\n(c)捷克",
        answer:"a"
    }
]

let score = 0;
for(let i = 0; i<questions.length; i++){
    let input=prompt(questions[i].prompt);
    if(input==questions[i].answer){
        score++;
        alert("賓狗!!");
    }
    else{
        alert("真不了解我");
    }
}
alert("總共答對" + score+"題!");

