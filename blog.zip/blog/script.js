// 要知道標題輸入了什麼,內容輸入了什麼,以及監聽發布按鈕有沒有被按

let title = document.getElementById("title");
let content = document.getElementById("content");
let btn = document.getElementById("btn");
// 取得外層div的元素
let list = document.getElementById("list");
// btn新增一個監聽器,點擊觸發,函式裡面放要執行什麼
// 用模板語法在裡面使用js的東西,用字串也可以但是沒辦法換行不好閱讀
// 也無法直接使用js的東西,還會有符號衝突
btn.addEventListener("click",function(){
    list.innerHTML = list.innerHTML + `
    <div class="article">
        <h2>${title.value}<h2>
        <p>${content.value}<P>
    <div>
    `;
    title.value = "";
    content.value = "";
})