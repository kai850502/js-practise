//密碼檢驗程式,最多只能輸入五次
//先設定密碼
let password = 910619;
let input;
//設定一個輸入次數
let input_count = 0;
//設定一個輸入次數上限
let input_limit = 5;
//用布林值判斷次數有無超過
let out_of_limit = false;
//當輸入不等於密碼或輸入不超過次數則重複迴圈
while(password!=input && !out_of_limit){
  input_count ++;
  if(input_count<=input_limit){
  input=prompt("請輸入密碼");
  }
  else(out_of_limit=true);
}
//跳出迴圈有兩種結果 1 是超過次數 2 是密碼等於input
if(out_of_limit){
  alert("再敢忘記阿!");
}
else{
  alert("登入成功");
}
