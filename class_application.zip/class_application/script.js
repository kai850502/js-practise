// class 物件的模板
// 假設老闆有3支手機用物件紀錄 號碼 年份 是否防水 函式:到2023出廠幾年
/*
let phone1 = {
    number:"123",
    year:2020,
    waterproof:false,
    phone_age:function(){
        return 2023 - this.year;
    }
}
let phone2 = {
    number:"788",
    year:2021,
    waterproof:false,
    phone_age:function(){
        return 2023 - this.year;
    }
}
let phone3 = {
    number:"899",
    year:2023,
    waterproof:false,
    phone_age:function(){
        return 2023 - this.year;
    }
}
*/
// 用class寫一個手機的模板 通常第一個字為大寫 constructor為初始函式
class Phone {
    constructor(number,year,waterproof){
        this.number=number;
        this.year=year;
        this.waterproof=waterproof;
    }
    phone_age(){
        return 2023 - this.year;
    }
}
let phone1 = new Phone("123",2020,false);
let phone2 = new Phone("788",2021,false);
let phone3 = new Phone("899",2023,false);
document.write(phone1.number,phone1.year,phone1.waterproof);
document.write("<br/>")
document.write(phone1.phone_age())