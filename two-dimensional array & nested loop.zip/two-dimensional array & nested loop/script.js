// 2維陣列 , 巢狀迴圈

let number= [
    [1,2,3],
    [87,87,87],
    [4,5,6],
    [0]
];
// [第一個陣列][第0項]
document.write(number[1][0])

// 上面用過的變數下面不能再用
// 會先i=0,j=0,1,2都跑完 再跑i=1,j=0,1,2 再跑i=2,j=0,1,2以此類推
for(let i=0;i<4;i++){
    for(let j=0;j<3;j++){
        document.write("i:"+ i + ",j:" + j);
        document.write("<br/>");
    }
}

// 想用一個巢狀迴圈取得二維陣列所有值
let number1= [
    [1,2,3],
    [87,87,87],
    [4,5,6],
    [0,5,4]
];
for(let a=0;a<number1.length;a++){
    for(let b=0;b<number1[a].length;b++){
        document.write(number1[a][b]);
    }
    document.write("<br/>");
}